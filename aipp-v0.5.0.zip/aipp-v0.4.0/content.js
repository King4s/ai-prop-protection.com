// --- AI-Prop-Protection: content.js v0.5.0 (Event-Driven) ---

const SITE_CONFIG = {
    'chat.openai.com': { messageContainer: '[data-message-author-role="assistant"]' },
    'chatgpt.com': { messageContainer: '[data-message-author-role="assistant"]' },
    'gemini.google.com': { messageContainer: '.model-response-text' },
    'aistudio.google.com': { messageContainer: '.model-response-text' },
    'copilot.microsoft.com': { messageContainer: 'cib-message[author="bot"]' },
    'www.bing.com': { messageContainer: 'cib-message[author="bot"]' },
    'claude.ai': { messageContainer: '[data-testid^="conversation-turn-"]' },
    'perplexity.ai': { messageContainer: '[class*="prose"]' },
    'chat.deepseek.com': { messageContainer: 'div[class^="message_message__"]' },
    'ai.meta.com': { messageContainer: '[data-testid="message-bubble-text-content"]' }
};

let DOMAINS_LIST = [];

// --- Core Scanning Logic ---
function performScan() {
    const hostname = window.location.hostname.replace('www.', '');
    const config = SITE_CONFIG[hostname];
    if (!config || DOMAINS_LIST.length === 0) {
        console.log("AI-Prop-Protection: Cannot scan. No config or domains list.");
        return;
    }

    console.log(`AI-Prop-Protection: Performing scan for ${hostname}`);
    const messageElements = document.querySelectorAll(config.messageContainer);
    messageElements.forEach(container => scanSingleElement(container, DOMAINS_LIST));
}

function scanSingleElement(element, domains) {
    const text = element.innerText.toLowerCase();
    if (!text) return;
    for (const domain of domains) {
        if (text.includes(domain)) {
            console.log(`AI-Prop-Protection: Found suspicious domain: "${domain}".`);
            createWarningBanner(domain, element);
            break;
        }
    }
}

function createWarningBanner(foundDomain, messageElement) {
    if (messageElement.querySelector('.ai-prop-protection-warning')) return;
    const banner = document.createElement('div');
    // ... (Styling is the same as before) ...
    banner.className = 'ai-prop-protection-warning';
    banner.style.backgroundColor = '#ff4d4d';
    banner.style.color = 'white';
    banner.style.padding = '10px';
    banner.style.margin = '10px 0';
    banner.style.borderRadius = '8px';
    banner.style.border = '2px solid #cc0000';
    banner.style.fontWeight = 'bold';
    banner.innerHTML = `⚠️ **AI-PROP-PROTECTION WARNING** ⚠️<br>This response may cite or reference a source (${foundDomain}) linked to a known disinformation network.`;
    messageElement.prepend(banner);
}

// --- Initialization and Listeners ---
async function initialize() {
    DOMAINS_LIST = (await (await fetch(chrome.runtime.getURL('domains.json'))).json()).domains || [];
    console.log(`AI-Prop-Protection: Loaded ${DOMAINS_LIST.length} domains.`);
    
    // Initial scan on load for static pages or already-present content
    setTimeout(performScan, 1500);
}

// Listen for the message from the popup.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "manualScan") {
        console.log("AI-Prop-Protection: Manual scan triggered from popup.");
        performScan();
    }
});

initialize();