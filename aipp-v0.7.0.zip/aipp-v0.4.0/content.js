// --- AI-Prop-Protection: content.js v0.7.0 (Context-Aware Engine) ---

const SITE_CONFIG = {
    'chat.openai.com': { messageContainer: '[data-message-author-role="assistant"] > div' },
    'chatgpt.com': { messageContainer: '[data-message-author-role="assistant"] > div' },
    'gemini.google.com': { messageContainer: '.model-response-text' },
    'aistudio.google.com': { messageContainer: '.model-response-text' },
    'copilot.microsoft.com': { messageContainer: 'div[data-content="ai-message"]' },
    'www.bing.com': { messageContainer: 'div[data-content="ai-message"]' },
    'claude.ai': { messageContainer: '[data-testid^="conversation-turn-"]' },
    'perplexity.ai': { messageContainer: '[class*="prose"]' },
    'chat.deepseek.com': { messageContainer: 'div[class^="message_message__"]' },
    'ai.meta.com': { messageContainer: '[data-testid="message-bubble-text-content"]' }
};

let DOMAINS_LIST = [];
let KEYWORDS_LIST = [];
let SCANNED_ELEMENTS = new WeakSet(); // To avoid scanning the same element multiple times

// --- Data Fetching Logic ---
async function fetchData(fileName) {
    try {
        const response = await fetch(chrome.runtime.getURL(fileName));
        return (await response.json()) || {};
    } catch (error) {
        console.error(`AI-Prop-Protection: Error loading ${fileName}:`, error);
        return {};
    }
}

// --- Warning Banners ---
function createWarningBanner(foundItem, messageElement, type) {
    const existingBanner = messageElement.querySelector('.ai-prop-protection-warning');
    // A red (domain) warning overrides a yellow (keyword) warning.
    if (existingBanner && existingBanner.dataset.type === 'domain') {
        return;
    }
    if (existingBanner) {
        existingBanner.remove();
    }

    const banner = document.createElement('div');
    banner.className = 'ai-prop-protection-warning';
    banner.dataset.type = type; // 'domain' or 'keyword'
    
    if (type === 'domain') {
        banner.style.backgroundColor = '#ff4d4d'; // Red
        banner.style.border = '2px solid #cc0000';
        banner.innerHTML = `⚠️ **AI-PROP-PROTECTION WARNING** ⚠️<br>This response may directly cite a source (${foundItem}) linked to a known disinformation network.`;
    } else { // Keyword
        banner.style.backgroundColor = '#ffc107'; // Yellow
        banner.style.border = '2px solid #d39e00';
        banner.innerHTML = `💡 **AI-PROP-PROTECTION CONTEXT-AWARENESS** 💡<br>This conversation mentions a known propaganda entity ("${foundItem}"). Please remain critical of the information presented.`;
    }

    // Common styling
    banner.style.color = 'black';
    banner.style.padding = '10px';
    banner.style.margin = '10px 0 0 0';
    banner.style.borderRadius = '8px';
    banner.style.fontWeight = 'bold';

    messageElement.append(banner);
}

// --- Core Scanning Logic ---
function performScan() {
    const hostname = window.location.hostname.replace('www.', '');
    const config = SITE_CONFIG[hostname];
    if (!config || (DOMAINS_LIST.length === 0 && KEYWORDS_LIST.length === 0)) return;

    const messageElements = document.querySelectorAll(config.messageContainer);
    messageElements.forEach(container => {
        if (!SCANNED_ELEMENTS.has(container)) {
            scanSingleElement(container, DOMAINS_LIST, KEYWORDS_LIST);
            SCANNED_ELEMENTS.add(container);
        }
    });
}

function scanSingleElement(element, domains, keywords) {
    const text = element.innerText.toLowerCase();
    if (!text) return;

    // Priority 1: Scan for domains (red warning)
    for (const domain of domains) {
        if (text.includes(domain)) {
            console.log(`AI-Prop-Protection: Found suspicious domain: "${domain}".`);
            chrome.runtime.sendMessage({ action: "threatDetected" });
            createWarningBanner(domain, element, 'domain');
            return; // Stop, as we've found the most severe threat type
        }
    }

    // Priority 2: Scan for keywords (yellow warning)
    for (const keyword of keywords) {
        if (text.includes(keyword)) {
            console.log(`AI-Prop-Protection: Found suspicious keyword: "${keyword}".`);
            // We don't message the badge for keywords to avoid excessive noise.
            createWarningBanner(keyword, element, 'keyword');
            return; // Stop, as we've found a warning
        }
    }
}


// --- Initialization and Listeners ---
async function initialize() {
    // Reset the threat count for this tab on startup
    chrome.runtime.sendMessage({ action: "resetThreatCount" });
    
    const domainsData = await fetchData('domains.json');
    const keywordsData = await fetchData('keywords.json');
    DOMAINS_LIST = domainsData.domains || [];
    KEYWORDS_LIST = keywordsData.keywords || [];

    // Use a robust observer to watch for new elements
    const observer = new MutationObserver((mutations) => {
        performScan();
    });
    observer.observe(document.body, { childList: true, subtree: true });
}

// Listen for a manual scan request from the popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "manualScan") {
        console.log("AI-Prop-Protection: Manual scan triggered.");
        // Reset and re-scan everything
        SCANNED_ELEMENTS = new WeakSet();
        chrome.runtime.sendMessage({ action: "resetThreatCount" });
        performScan();
    }
});

initialize();