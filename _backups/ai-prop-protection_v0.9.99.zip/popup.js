﻿document.getElementById('scanButton').addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs.length === 0) return;
        const activeTab = tabs[0];
        
        console.log("AIPP Popup: Injecting script into tab " + activeTab.id);
        chrome.scripting.executeScript({
            target: { tabId: activeTab.id, allFrames: true }, // Inject into all frames
            files: ['content.js']
        }, () => {
            if (chrome.runtime.lastError) {
                console.error("Injection failed:", chrome.runtime.lastError.message);
                return;
            }
            console.log("AIPP Popup: Injection successful. Sending scan request.");
            chrome.tabs.sendMessage(activeTab.id, { action: "executeScan" });
        });
    });
});
