# =============================================================================
# Project Genesis: The AI-Driven Project Builder
# Version: 2.0 (GUI Edition)
# Description: A graphical wizard for scaffolding new projects.
# =============================================================================

# --- Load Required Assemblies for GUI ---
Add-Type -AssemblyName PresentationFramework, System.Windows.Forms

# --- Paths ---
$ScriptRoot = $PSScriptRoot
$TemplatesPath = Join-Path $ScriptRoot "templates"

# --- Load XAML GUI Definition ---
try {
    $xamlPath = Join-Path $ScriptRoot "MainWindow.xaml"
    [xml]$xaml = Get-Content -Path $xamlPath
    $reader = (New-Object System.Xml.XmlNodeReader $xaml)
    $window = [Windows.Markup.XamlReader]::Load($reader)
} catch {
    [System.Windows.Forms.MessageBox]::Show("Error loading GUI definition (MainWindow.xaml). Make sure the file exists in the same directory as the script.", "Fatal Error", "OK", "Error")
    return
}

# --- Connect GUI Elements to PowerShell Variables ---
$ProjectNameTextBox = $window.FindName("ProjectNameTextBox")
$TemplateComboBox = $window.FindName("TemplateComboBox")
$GitHubUrlTextBox = $window.FindName("GitHubUrlTextBox")
$CreateProjectButton = $window.FindName("CreateProjectButton")

# --- Populate Templates ---
$templateFiles = Get-ChildItem -Path $TemplatesPath -Filter "template.json" -Recurse
$templateObjects = @()
foreach ($file in $templateFiles) {
    try {
        $templateData = Get-Content -Path $file.FullName | ConvertFrom-Json
        $templateObjects += [PSCustomObject]@{
            Name = $templateData.name
            Description = $templateData.description
            Path = $file.DirectoryName
        }
    } catch {
        Write-Warning "Could not parse template file: $($file.FullName)"
    }
}
$TemplateComboBox.ItemsSource = $templateObjects
$TemplateComboBox.SelectedIndex = 0

# --- Define Button Click Action ---
$CreateProjectButton.add_Click({
    $ProjectName = $ProjectNameTextBox.Text
    $SelectedTemplate = $TemplateComboBox.SelectedItem
    $GitHubUrl = $GitHubUrlTextBox.Text

    # --- Validation ---
    if ([string]::IsNullOrWhiteSpace($ProjectName)) {
        [System.Windows.Forms.MessageBox]::Show("Please enter a project name.", "Validation Error", "OK", "Warning")
        return
    }
    if ($null -eq $SelectedTemplate) {
        [System.Windows.Forms.MessageBox]::Show("Please select a project template.", "Validation Error", "OK", "Warning")
        return
    }

    $ProjectPath = Join-Path $ScriptRoot $ProjectName
    if (Test-Path $ProjectPath) {
        [System.Windows.Forms.MessageBox]::Show("A folder named '$ProjectName' already exists. Please choose another name.", "Validation Error", "OK", "Error")
        return
    }

    # --- Disable Button during operation ---
    $CreateProjectButton.IsEnabled = $false
    $CreateProjectButton.Content = "Creating..."

    # --- Project Creation Logic (runs in the background) ---
    Copy-Item -Path "$($SelectedTemplate.Path)\*" -Destination $ProjectPath -Recurse -Force
    
    # AI File Generation, Git Init, etc. would go here...
    # (For simplicity, this example just creates the folder structure)
    # This part can be expanded with the logic from the previous script.

    # --- Final Message and Close ---
    [System.Windows.Forms.MessageBox]::Show("Project '$ProjectName' created successfully using the '$($SelectedTemplate.Name)' template!", "Success", "OK", "Information")
    $window.Close()
})

# --- Show the GUI ---
$window.ShowDialog() | Out-Null