// --- AI-Prop-Protection: content.js v0.7.1 (Context-Aware Engine) ---

const SITE_CONFIG = {
    'chat.openai.com': { messageContainer: '[data-message-author-role="assistant"] > div' },
    'chatgpt.com': { messageContainer: '[data-message-author-role="assistant"] > div' },
    'gemini.google.com': { messageContainer: '.model-response-text' },
    // *** NEW, CORRECTED SELECTOR FOR AI STUDIO ***
    'aistudio.google.com': { messageContainer: 'ms-cmark-node' },
    // *** END OF CHANGE ***
    'copilot.microsoft.com': { messageContainer: 'div[data-content="ai-message"]' },
    'www.bing.com': { messageContainer: 'div[data-content="ai-message"]' },
    'claude.ai': { messageContainer: '[data-testid^="conversation-turn-"]' },
    'perplexity.ai': { messageContainer: '[class*="prose"]' },
    'chat.deepseek.com': { messageContainer: 'div[class^="message_message__"]' },
    'ai.meta.com': { messageContainer: '[data-testid="message-bubble-text-content"]' }
};

// ... resten af filen er uændret fra v0.7.0 ...
let DOMAINS_LIST = [];
let KEYWORDS_LIST = [];
let SCANNED_ELEMENTS = new WeakSet();

async function fetchData(fileName) {
    try {
        const response = await fetch(chrome.runtime.getURL(fileName));
        return (await response.json()) || {};
    } catch (error) {
        console.error(`AI-Prop-Protection: Error loading ${fileName}:`, error);
        return {};
    }
}

function createWarningBanner(foundItem, messageElement, type) {
    const existingBanner = messageElement.querySelector('.ai-prop-protection-warning');
    if (existingBanner && existingBanner.dataset.type === 'domain') {
        return;
    }
    if (existingBanner) {
        existingBanner.remove();
    }

    const banner = document.createElement('div');
    banner.className = 'ai-prop-protection-warning';
    banner.dataset.type = type;
    
    if (type === 'domain') {
        banner.style.backgroundColor = '#ff4d4d';
        banner.style.border = '2px solid #cc0000';
        banner.innerHTML = `⚠️ **AI-PROP-PROTECTION WARNING** ⚠️<br>This response may directly cite a source (${foundItem}) linked to a known disinformation network.`;
    } else {
        banner.style.backgroundColor = '#ffc107';
        banner.style.border = '2px solid #d39e00';
        banner.innerHTML = `💡 **AI-PROP-PROTECTION CONTEXT-AWARENESS** 💡<br>This conversation mentions a known propaganda entity ("${foundItem}"). Please remain critical of the information presented.`;
    }

    banner.style.color = 'black';
    banner.style.padding = '10px';
    banner.style.margin = '10px 0 0 0';
    banner.style.borderRadius = '8px';
    banner.style.fontWeight = 'bold';

    messageElement.append(banner);
}

function performScan() {
    const hostname = window.location.hostname.replace('www.', '');
    const config = SITE_CONFIG[hostname];
    if (!config || (DOMAINS_LIST.length === 0 && KEYWORDS_LIST.length === 0)) return;

    const messageElements = document.querySelectorAll(config.messageContainer);
    messageElements.forEach(container => {
        if (!SCANNED_ELEMENTS.has(container)) {
            scanSingleElement(container, DOMAINS_LIST, KEYWORDS_LIST);
            SCANNED_ELEMENTS.add(container);
        }
    });
}

function scanSingleElement(element, domains, keywords) {
    const text = element.innerText.toLowerCase();
    if (!text) return;

    for (const domain of domains) {
        if (text.includes(domain)) {
            console.log(`AI-Prop-Protection: Found suspicious domain: "${domain}".`);
            chrome.runtime.sendMessage({ action: "threatDetected" });
            createWarningBanner(domain, element, 'domain');
            return;
        }
    }

    for (const keyword of keywords) {
        if (text.includes(keyword)) {
            console.log(`AI-Prop-Protection: Found suspicious keyword: "${keyword}".`);
            createWarningBanner(keyword, element, 'keyword');
            return;
        }
    }
}

async function initialize() {
    chrome.runtime.sendMessage({ action: "resetThreatCount" });
    const domainsData = await fetchData('domains.json');
    const keywordsData = await fetchData('keywords.json');
    DOMAINS_LIST = domainsData.domains || [];
    KEYWORDS_LIST = keywordsData.keywords || [];

    const observer = new MutationObserver((mutations) => {
        performScan();
    });
    observer.observe(document.body, { childList: true, subtree: true });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "manualScan") {
        SCANNED_ELEMENTS = new WeakSet();
        chrome.runtime.sendMessage({ action: "resetThreatCount" });
        performScan();
    }
});

initialize();