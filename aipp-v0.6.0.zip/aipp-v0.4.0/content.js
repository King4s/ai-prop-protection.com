// --- AI-Prop-Protection: content.js v0.6.0 (Event-Driven & Badge Support) ---

const SITE_CONFIG = {
    'chat.openai.com': { messageContainer: '[data-message-author-role="assistant"] > div' },
    'chatgpt.com': { messageContainer: '[data-message-author-role="assistant"] > div' },
    'gemini.google.com': { messageContainer: '.model-response-text' },
    'aistudio.google.com': { messageContainer: '.model-response-text' },
    'copilot.microsoft.com': { messageContainer: 'cib-message[author="bot"]' },
    'www.bing.com': { messageContainer: 'cib-message[author="bot"]' },
    'claude.ai': { messageContainer: '[data-testid^="conversation-turn-"]' },
    'perplexity.ai': { messageContainer: '[class*="prose"]' },
    'chat.deepseek.com': { messageContainer: 'div[class^="message_message__"]' },
    'ai.meta.com': { messageContainer: '[data-testid="message-bubble-text-content"]' }
};

let DOMAINS_LIST = [];
let SCANNED_ELEMENTS = new WeakSet(); // For at undgå at scanne det samme element flere gange

// --- Core Scanning Logic ---
function performScan() {
    const hostname = window.location.hostname.replace('www.', '');
    const config = SITE_CONFIG[hostname];
    if (!config || DOMAINS_LIST.length === 0) return;

    const messageElements = document.querySelectorAll(config.messageContainer);
    messageElements.forEach(container => {
        if (!SCANNED_ELEMENTS.has(container)) {
            scanSingleElement(container, DOMAINS_LIST);
            SCANNED_ELEMENTS.add(container); // Markér som scannet
        }
    });
}

function scanSingleElement(element, domains) {
    const text = element.innerText.toLowerCase();
    if (!text) return;

    for (const domain of domains) {
        if (text.includes(domain)) {
            console.log(`AI-Prop-Protection: Found suspicious domain: "${domain}".`);
            // Send besked til background script for at opdatere badget
            chrome.runtime.sendMessage({ action: "threatDetected" });
            // Indsæt det lokale advarselsbanner
            createWarningBanner(domain, element);
            break; // Stop efter at have fundet den første trussel i denne blok
        }
    }
}

function createWarningBanner(foundDomain, messageElement) {
    // Denne funktion indsætter nu banneret i bunden
    const banner = document.createElement('div');
    banner.className = 'ai-prop-protection-warning';
    banner.style.backgroundColor = '#ff4d4d';
    banner.style.color = 'white';
    banner.style.padding = '10px';
    banner.style.margin = '10px 0 0 0'; // Margin i toppen
    banner.style.borderRadius = '8px';
    banner.style.border = '2px solid #cc0000';
    banner.style.fontWeight = 'bold';
    banner.innerHTML = `⚠️ **AI-PROP-PROTECTION WARNING** ⚠️<br>This response may cite or reference a source (${foundDomain}) linked to a known disinformation network.`;
    // **VIGTIG ÆNDRING: Brug append() i stedet for prepend()**
    messageElement.append(banner);
}

// --- Initialization and Listeners ---
async function initialize() {
    // Nulstil tælleren for denne fane ved start
    chrome.runtime.sendMessage({ action: "resetThreatCount" });
    
    DOMAINS_LIST = (await (await fetch(chrome.runtime.getURL('domains.json'))).json()).domains || [];
    
    // Brug en mere robust observer til at se efter nye elementer
    const observer = new MutationObserver((mutations) => {
        performScan();
    });
    observer.observe(document.body, { childList: true, subtree: true });
}

// Lyt efter manuel scanning fra popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "manualScan") {
        console.log("AI-Prop-Protection: Manual scan triggered.");
        // Nulstil og gen-scan alt
        SCANNED_ELEMENTS = new WeakSet();
        chrome.runtime.sendMessage({ action: "resetThreatCount" });
        performScan();
    }
});

initialize();