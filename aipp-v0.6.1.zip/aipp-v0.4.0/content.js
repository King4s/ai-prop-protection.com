// --- AI-Prop-Protection: content.js v0.6.1 ---

// --- CONFIGURATION ---
const SITE_CONFIG = {
    'chat.openai.com': { messageContainer: '[data-message-author-role="assistant"] > div' },
    'chatgpt.com': { messageContainer: '[data-message-author-role="assistant"] > div' },
    'gemini.google.com': { messageContainer: '.model-response-text' },
    'aistudio.google.com': { messageContainer: '.model-response-text' },
    // *** NY, FORBEDRET SELECTOR FOR COPILOT/BING ***
    'copilot.microsoft.com': { messageContainer: 'cib-message[author="bot"]', shadowHost: true },
    'www.bing.com': { messageContainer: 'cib-message[author="bot"]', shadowHost: true },
    // *** SLUT PÅ ÆNDRING ***
    'claude.ai': { messageContainer: '[data-testid^="conversation-turn-"]' },
    'perplexity.ai': { messageContainer: '[class*="prose"]' },
    'chat.deepseek.com': { messageContainer: 'div[class^="message_message__"]' },
    'ai.meta.com': { messageContainer: '[data-testid="message-bubble-text-content"]' }
};

// ... resten af filen er uændret ...
// NOTE: Jeg har opdateret scanningsfunktionen til at håndtere Shadow DOM

let DOMAINS_LIST = [];
let SCANNED_ELEMENTS = new WeakSet();

function performScan() {
    const hostname = window.location.hostname.replace('www.', '');
    const config = SITE_CONFIG[hostname];
    if (!config || DOMAINS_LIST.length === 0) return;

    const messageElements = document.querySelectorAll(config.messageContainer);
    messageElements.forEach(container => {
        if (!SCANNED_ELEMENTS.has(container)) {
            // Håndter Shadow DOM, hvis det er specificeret i config
            const targetElement = config.shadowHost ? container.shadowRoot : container;
            if (targetElement) {
                scanSingleElement(targetElement, DOMAINS_LIST);
            }
            SCANNED_ELEMENTS.add(container);
        }
    });
}

function scanSingleElement(element, domains) {
    // ... (resten af funktionen er uændret)
    const text = element.innerText.toLowerCase();
    if (!text) return;

    for (const domain of domains) {
        if (text.includes(domain)) {
            console.log(`AI-Prop-Protection: Found suspicious domain: "${domain}".`);
            chrome.runtime.sendMessage({ action: "threatDetected" });
            // Vi skal sikre, at banneret vedhæftes det synlige element, ikke shadow root
            createWarningBanner(domain, element.host || element); 
            break;
        }
    }
}

// ... resten af filen er identisk med v0.6.0 ...
function createWarningBanner(foundDomain, messageElement) {
    const banner = document.createElement('div');
    banner.className = 'ai-prop-protection-warning';
    banner.style.backgroundColor = '#ff4d4d';
    banner.style.color = 'white';
    banner.style.padding = '10px';
    banner.style.margin = '10px 0 0 0'; 
    banner.style.borderRadius = '8px';
    banner.style.border = '2px solid #cc0000';
    banner.style.fontWeight = 'bold';
    banner.innerHTML = `⚠️ **AI-PROP-PROTECTION WARNING** ⚠️<br>This response may cite or reference a source (${foundDomain}) linked to a known disinformation network.`;
    messageElement.append(banner);
}

async function initialize() {
    chrome.runtime.sendMessage({ action: "resetThreatCount" });
    DOMAINS_LIST = (await (await fetch(chrome.runtime.getURL('domains.json'))).json()).domains || [];
    const observer = new MutationObserver((mutations) => {
        performScan();
    });
    observer.observe(document.body, { childList: true, subtree: true });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "manualScan") {
        SCANNED_ELEMENTS = new WeakSet();
        chrome.runtime.sendMessage({ action: "resetThreatCount" });
        performScan();
    }
});

initialize();